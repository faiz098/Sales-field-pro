SALES FIELD PRO — PROYEK ANDROID

Isi:
- Aplikasi Android native wrapper berbasis WebView
- Aplikasi Sales Field Pro disertakan sebagai aset lokal sehingga antarmuka inti dapat dibuka tanpa hosting
- Dashboard, database prospek lokal, skrip penjualan, laporan, ekspor CSV dan backup JSON mengikuti versi web yang disertakan

CARA MEMBANGUN APK:
1. Pasang Android Studio di komputer (Windows/macOS/Linux) dan Android SDK Platform 35.
2. Ekstrak ZIP ini.
3. Buka folder SalesFieldProAndroid di Android Studio.
4. Tunggu Gradle Sync selesai; izinkan Android Studio mengunduh plugin/dependensi yang diperlukan.
5. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK debug biasanya muncul di app/build/outputs/apk/debug/app-debug.apk.
7. Pindahkan APK ke HP Android, izinkan pemasangan dari sumber yang digunakan, lalu instal.

CATATAN:
- Paket ini adalah proyek sumber Android Studio, bukan APK terkompilasi.
- Untuk APK rilis yang dibagikan luas, buat signing key sendiri dan gunakan Build > Generate Signed Bundle / APK.
- Data disimpan secara lokal pada WebView/perangkat; tidak ada sinkronisasi antarperangkat atau login multi-sales.
- Lakukan backup berkala dari dalam aplikasi. Menghapus data aplikasi dapat menghapus prospek lokal.
- WhatsApp hanya muncul untuk prospek yang ditandai telah memberi izin follow-up.
